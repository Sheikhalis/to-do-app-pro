#! /usr/bin/env node
import inquirer from "inquirer";
import chalk from "chalk";
import chalkAnimation, { rainbow } from "chalk-animation";
import Choices from "inquirer/lib/objects/choices.js";
async function welcome(){
const rainbow = chalkAnimation.rainbow ("Start the to do list Application");
rainbow.stop()
}
welcome();

let todos:string[]=[];
let loop =true;

while(loop){
    const answers :{
        TODO:string,
        addmore:boolean
    } =await inquirer.prompt([
        {
            type : "input",
            name:"TODO",
            message : "What do you want to add your TODO?"
        },
        {
            type:"confirm",
            name:"add more",
            message : "Do you want to add more todo?",
            default:false
        },
    ]);
    const {TODO,addmore}=answers
    console.log(answers)
  loop=addmore
  if(TODO){
  todos.push(TODO)
  }else{
    console.log("kindly add valid input")
  }
}
if(todos.length>0){
    console.log("Your to do list:")
todos.forEach(TODO=>{
console.log(TODO)
});
}else{
    console.log("No todos Found")
}
//console.log(todos)
